from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import json

bot = Bot(token="YOUR_TELEGRAM_BOT_TOKEN")
dp = Dispatcher(bot)

with open("messages.json", "r", encoding="utf-8") as f:
    TEXTS = json.load(f)

@dp.message_handler(commands=["start", "post"])
async def send_announcement(message: types.Message):
    sent = await message.answer(TEXTS["en"], reply_markup=lang_buttons())
    await bot.pin_chat_message(message.chat.id, sent.message_id)

def lang_buttons():
    buttons = [
        [
            InlineKeyboardButton("🇬🇧", callback_data="en"),
            InlineKeyboardButton("🇵🇱", callback_data="pl"),
            InlineKeyboardButton("🇩🇪", callback_data="de")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

@dp.callback_query_handler(lambda c: c.data in ["en", "pl", "de"])
async def switch_lang(callback_query: types.CallbackQuery):
    lang = callback_query.data
    try:
        await bot.edit_message_text(
            TEXTS[lang],
            chat_id=callback_query.message.chat.id,
            message_id=callback_query.message.message_id,
            reply_markup=lang_buttons()
        )
        await callback_query.answer(f"Switched to {lang.upper()}")
    except Exception:
        await callback_query.answer("⚠️ Could not switch language. Please try again later.")

if __name__ == '__main__':
    executor.start_polling(dp)